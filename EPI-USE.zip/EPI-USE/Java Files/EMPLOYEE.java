package com.example.scpoc;

public class EMPLOYEE {
    int id;
    String fname;
    String lname;
    String position;
    int report;
    String birthdate;
    Double salary;
}
