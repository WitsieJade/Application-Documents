package com.example.scpoc;

import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Vector;

public class Offenses {
    Vector<Double> coeff_vec;

    public Vector<Vector<Double>> inverse(Vector<Vector<Double>> matrix)
    {
        int n = matrix.size(); //must be square matrix
        Vector<Vector<Double>> a = new Vector<Vector<Double>>(n);
        a.setSize(n); //shouldn't have to do this but get errors if not
        Vector<Vector<Double>> b = new Vector<Vector<Double>>(n);
        b.setSize(n); //shouldn't have to do this but get errors if not
        for (int i=0; i<n; i++){
            a.set(i, new Vector<Double>());
            a.get(i).setSize(n);
            b.set(i, new Vector<Double>());
            b.get(i).setSize(n);
            //makes the column number of elements equal to row elements
        }
        Vector<Integer> index = new Vector<Integer>();
        index.setSize(n);
        for (int i=0; i<n; i++) {
            b.get(i).set(i, 1.0); //main diagonal all 1
        }

        //next part creates upper triangle by using Gaussian elimination
        Vector<Double> c = new Vector<Double>();
        c.setSize(n);

        for (int i=0; i<n; i++){
            index.set(i,i);
        }

        Double c0;
        Double c1;
        for (int i=0; i<n; i++){
            c1=0.0;
            for (int j=0; j<n; j++){
                c0=Math.abs(matrix.get(i).get(j));
                if (c0>c1){
                    c1=c0;
                }
            }
            c.set(i,c1);
        }

        //find pivoting number for Gauss
        int k=0;
        int iTemp;
        Double pivJ;
        Double piv0;
        Double piv1;
        Double temp0;
        for (int j=0; j<n-1; j++){
            piv1=0.0;
            for (int i=j; i<n; i++){
                piv0=Math.abs(matrix.get(index.get(i)).get(j));
                piv0=piv0/c.get(index.get(i)); //watch out for divide by zero, might need epsilom
                if (piv0>piv1){
                    piv1=piv0;
                    k=i;
                }
            }

            //swapping rows and dividing to make triangle
            iTemp=index.get(j);
            index.set(j,index.get(k));
            index.set(k,iTemp);
            for (int i=j+1; i<n; i++){
                pivJ=matrix.get(index.get(i)).get(j)/matrix.get(index.get(j)).get(j);
                matrix.get(index.get(i)).set(j,pivJ);
                for (int l=j+1; l<n; l++){
                    temp0=matrix.get(index.get(i)).get(l);
                    matrix.get(index.get(i)).set(l, temp0 - pivJ*matrix.get(index.get(j)).get(l));
                }
            }
        }

        Double temp;
        int index_j;
        int index_i;
        // Update the matrix b[i][j] with the ratios stored
        for (int i=0; i<n-1; i++) {
            for (int j = i + 1; j < n; j++) {
                for (k = 0; k < n; k++) { //k was already defined earlier
                    index_j=index.get(j);
                    index_i=index.get(i);
                    temp=b.get(index_j).get(k);
                    if (matrix.get(index_j).get(i)==null){
                        matrix.get(index_j).set(i, 0.0);
                        Log.i("inverse","matrix["+Integer.toString(index_j)+"]["+Integer.toString(i)+"] was null");
                    }
                    if (b.get(index_i).get(k)==null){
                        b.get(index_i).set(k, 0.0);
                        Log.i("inverse","b["+Integer.toString(index_i)+"]["+Integer.toString(k)+"] was null");
                    }
                    if (index_j>=n){
                        Log.i("inverse", "index_j too large");
                    }
                    if (k>=n){
                        Log.i("inverse", "k too large");
                    }
                    if (temp==null){
                        temp=0.0;
                        Log.i("inverse", "temp was null");
                    }
                    Double setting0=matrix.get(index_j).get(i);
                    Double setting1=b.get(index_i).get(k);
                    Double setting=temp - ( setting0*setting1 );
                    b.get(index_j).set(k, setting);
                }
            }
        }

        // Perform backward substitutions
        for (int i=0; i<n; i++)
        {
            a.get(n-1).set(i, b.get(index.get(n-1)).get(i)/matrix.get(index.get(n-1)).get(n-1));
            for (int j=n-2; j>=0; --j)
            {
                a.get(j).set(i, b.get(index.get(j)).get(i));
                for (k=j+1; k<n; ++k) //k was already defined earlier
                {
                    temp = matrix.get(index.get(j)).get(k)*matrix.get(k).get(i);
                    a.get(j).set(i, a.get(j).get(i)-temp);
                }
                a.get(j).set(i, a.get(j).get(i)/matrix.get(index.get(j)).get(j));
            }
        }
        return a;
    }

    public Double vecmul(Vector<Double> first_mat, Vector<Double> second_mat){
        Double return_num = 0.0;

        for (int r=0; r<first_mat.size(); r++){ //both must be of equal size so can use first or second matrix
            return_num+=first_mat.get(r)*second_mat.get(r);
        }
        return(return_num);
    }

    public Vector<Vector<Double>> matmul(Vector<Vector<Double>> first_mat, Vector<Vector<Double>> second_mat){
        Vector<Vector<Double>> return_mat = new Vector<Vector<Double>>();
        return_mat.setSize(first_mat.size()); //set row size
        for (int i=0; i<return_mat.size(); i++){
            return_mat.set(i, new Vector<>());
            return_mat.get(i).setSize(second_mat.get(0).size()); //set column size
        }

        Double return_cell;
        Log.i("matmul",Integer.toString(first_mat.size())+"x"+Integer.toString(first_mat.get(0).size())+" times "
        +Integer.toString(second_mat.size())+"x"+Integer.toString(second_mat.get(0).size()));
        Log.i("matmul", "first_mat.size()="+Integer.toString(first_mat.size()));
        Log.i("matmul", "second_mat.get(0).size()="+Integer.toString(second_mat.get(0).size()));
        for (int r=0; r<first_mat.size(); r++){
            for (int c=0; c<second_mat.get(0).size(); c++){
                return_cell=0.0;
                for (int rc=0; rc<second_mat.size(); rc++){
                    if (first_mat.get(r).get(rc)==null) {
                        Log.i("matmul", "null at first_mat["+Integer.toString(r)+"]["+Integer.toString(rc)+"]");
                    }
                    if (second_mat.get(rc).get(c)==null) {
                        Log.i("matmul", "null at second_mat["+Integer.toString(rc)+"]["+Integer.toString(c)+"]");
                    }
                    return_cell += first_mat.get(r).get(rc) * second_mat.get(rc).get(c); //calculates cell value
                }
                return_mat.get(r).set(c, return_cell); //replaces element in row r column c with new value
            }
        }
        return(return_mat);
    }

    public Vector<Vector<Double>> transpose(Vector<Vector<Double>> matrix){
        Vector<Vector<Double>> return_mat=new Vector<Vector<Double>>();
        return_mat.setSize(matrix.get(0).size()); //set row size
        for (int i=0; i<return_mat.size(); i++){
            return_mat.set(i, new Vector<Double>());
            return_mat.get(i).setSize(matrix.size()); //set column size
        }
        for (int i=0; i<matrix.size(); i++){
            for (int k=0; k<matrix.get(0).size(); k++){
                return_mat.get(k).set(i, matrix.get(i).get(k));
            }
        }
        return(return_mat);
    }

    /*
    This function is to import the data
    from (insert data type) in order to
    have formatted data for learning
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void importData(){
        /*
        a list of offenses, seperated by the ',' character. Offenses are numerical and correspond as follows:
        0: late
        1: absenteeism
        2: dress code misconduct
        3: theft
        4: harassment
        5: insubordination
        6: intimidation
        7: unauthorised substance use (typically unauthorised in office setting)
        8: poor performance
        the offenses are lead by a date in standard format yyyy-MM-dd

        The y values are as follows:
        0: Time management course
        1: Presentability course
        2: Theft awareness course
        3: Diversity course
        4: Power management course
        5: Substance abuse awareness course
        6: Positive work environment course
         */
        Vector<Vector<Double>> x_train= new Vector<Vector<Double>>();
        x_train.setSize(219); //219 vectors of data
        for (int i=0; i<219; i++){
            x_train.set(i, new Vector<Double>());
            x_train.get(i).setSize(9); //each vector has 9 variables
        }
        Vector<Double> y_train = new Vector<Double>();
        y_train.setSize(219); //219 vectors of data

        Path pathToFile = Paths.get("C:/Users/CriticalHit/Documents/Training Data/offenses.csv");

        try (BufferedReader br = Files.newBufferedReader(pathToFile, StandardCharsets.US_ASCII)){
            String line = br.readLine();
            String[] current_vector = line.split(",");
            int i=0;

            while (line!=null){
                for (int k=0; k<9; k++){
                    x_train.get(i).set(k,Double.parseDouble(current_vector[k]+".0"));
                }
                y_train.set(i,Double.parseDouble(current_vector[9]+".0"));
                line= br.readLine();
                i++;
            }
        } catch (IOException ioe){
            ioe.printStackTrace();
            System.err.println("something went wrong with import dataset"); //check logcat for this
            //in the case of the above error, to keep things moving so long:
            linReg tempClass = new linReg();
            String[] lines = tempClass.training_data.split("\n");
            String[] current_vector=lines[0].split(","); //just for sizing sake, will do it again in the loop
            for (int i=0; i<lines.length; i++){
                current_vector=lines[i].split(",");
                for (int k=0; k<9; k++){
                    x_train.get(i).set(k,Double.parseDouble(current_vector[k]+".0"));

                }
                /*for testing, currently appears to work:
                for (int k=0; k<9; k++){
                    Log.v("training test",Double.toString(x_train.get(i).get(k)));
                }
                */

                y_train.set(i,Double.parseDouble(current_vector[9]+".0"));
            }
        }
        coeff_vec = initialise(x_train, y_train).get(0);
    }

    /*
    This function learns the app using linear regression
     */
    public Vector<Vector<Double>> initialise(Vector<Vector<Double>> x, Vector<Double> y){
        Vector<Vector<Double>> xT=transpose(x);
        //Log.i("matmul check", Double.toString(xT.get(0).get(0)));
        Vector<Vector<Double>> ans_step_one=matmul(xT, x);
        //ans_1=(X^T)X
        Vector<Vector<Double>> ans_step_two=inverse(ans_step_one);
        //ans_2=(X^T X)^(-1)
        Vector<Vector<Double>> ans_final=matmul(ans_step_two, xT);
        //ans_final=(X^T X)^(-1) X^T
        Vector<Vector<Double>> Y=new Vector<Vector<Double>>();
        Y.add(y);
        return(matmul(ans_final,Y));
        //return: (X^T X)^(-1) X^T Y
    }

    //count offenses
    //put into vector form
    //use vector form as courseRecommend input
    public String courseRecommend(Vector<Double> dataset){

        long course_value = Math.round(vecmul(dataset,coeff_vec));
        if (course_value==0){
            return("Time management course");
        }
        else if (course_value==1){
            return("Presentability Course");
        }
        else if (course_value==2){
            return("Theft Awareness Course");
        }
        else if (course_value==3){
            return("Diversity Course");
        }
        else if (course_value==4){
            return("Power Management Course");
        }
        else if (course_value==5){
            return("Substance Abuse Awareness Course");
        }
        else{
            return("Positive Work Environment Course");
        }
    }
}
