package com.example.scpoc;

import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.text.SimpleDateFormat;

public class DatabaseHelper extends SQLiteOpenHelper {
    //class variables
    private String DB_PATH;
    private String DB_NAME;
    private SimpleDateFormat simp_date = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");

    //constructor
    public DatabaseHelper(Context c, String dbName){
        super(c, dbName + ".db", null, 1); //super is for the SQLiteOpenHelper
        DB_NAME= dbName + ".db";
    }

    public String getNow(){
        return simp_date.format(new java.util.Date());
    }

    /*Methods doQuery and doUpdate have polymorphism
        first is with parameters variable
        second is without
     */
    public Cursor doQuery(String sql, String[] parameters){
        try{
            Cursor myCur = getReadableDatabase().rawQuery(sql, parameters);
            return myCur;
        } catch (SQLException mySQLException){
            System.err.println("doQuery error:\n"+sql+" "+parameters); //updates error log
            mySQLException.printStackTrace(System.err); //tell us what is going on
            return null;
        }
    }

    public Cursor doQuery(String sql){
        try{
            Cursor myCur = getReadableDatabase().rawQuery(sql, null);
            return myCur;
        } catch(SQLException mySQLException){
            System.err.println("doQuery (no parameters) error:\n"+sql); //updates error log
            mySQLException.printStackTrace(System.err); //tell us what is going on
            return null;
        }
    }

    public void doUpdate(String sql, String[] parameters){
        try{
            getWritableDatabase().execSQL(sql, parameters);
        } catch (SQLException mySQLException){
            System.err.println("doUpdate error:\n"+sql+" "+parameters); //updates error log
            mySQLException.printStackTrace(System.err); //tell us what is going on
        }
    }

    public void doUpdate(String sql){
        try{
            this.getWritableDatabase().execSQL(sql);
        } catch (SQLException mySQLException){
            System.err.println("doUpdate (no parameters) error:\n" + sql); //updates error log
            mySQLException.printStackTrace(System.err); //tell us what is going on
        }
    }

    //for use if space becomes an issue or need for debug:
    public long getSize(){
        //Open database object in "read" mode:
        final SQLiteDatabase db = getReadableDatabase();

        final String dbPath = db.getPath(); //path to database object, needed for reference below
        final File dbFile = new File(dbPath); //the object in its file format
        final long dbFileLength = dbFile.length(); //finally, we have the length

        return (dbFileLength);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE EMPLOYEES(ID INT PRIMARY KEY, FNAME TEXT, LNAME TEXT, POSITION TEXT, REPORT INT, BIRTHDATE TEXT, SALARY FLOAT(2), OFFENSES TEXT)");
        /*
        TABLE:
            EMPLOYEES
        FIELDS:
            ID
                employee ID as primary key as it is impartial and has no bias
            FNAME
                employee's first name. Necessary field
            LNAME
                employee's last name. Not necessary as certain people only have one name
            POSITION
                description of the employee's position. Example, "manager"
            REPORT
                the ID of the employee that they work under. (The parent of the employee child node)
            BIRTHDATE
                birth date in format yyyy-MM-dd
            SALARY
                salary in Rands to two decimal places
            OFFENSES
                a list of offenses, seperated by the ',' character. Offenses are numerical and correspond as follows:
                    0: late
                    1: absenteeism
                    2: dress code misconduct
                    3: theft
                    4: harassment
                    5: insubordination
                    6: intimidation
                    7: unauthorised substance use (typically unauthorised in office setting)
                    8: poor performance
                the offenses are lead by a date in standard format yyyy-MM-dd
         */
    }

    public SQLiteDatabase getDB(){
        return getWritableDatabase();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }
}
