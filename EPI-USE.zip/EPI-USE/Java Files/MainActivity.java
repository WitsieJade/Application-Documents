package com.example.scpoc;

import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.scpoc.databinding.ActivityMainBinding;

import java.util.Vector;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;
    DatabaseHelper myDB; //creates DatabaseHelpter object
    Vector<EMPLOYEE> Employees = new Vector<EMPLOYEE>();
    Vector<String> spinnerList = new Vector<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        myDB=new DatabaseHelper(this, "app"); //database will be called app.db

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_offenses)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_main);
        NavigationUI.setupWithNavController(binding.navView, navController);
        getEmployees();
    }


    public void getEmployees(){
        Cursor c = myDB.doQuery("SELECT * FROM EMPLOYEES");
        EMPLOYEE employee = new EMPLOYEE();
        while (c.moveToNext()){
            employee = new EMPLOYEE();
            employee.id=c.getInt(c.getColumnIndex("ID"));
            employee.fname=c.getString(c.getColumnIndex("FNAME"));
            employee.lname=c.getString(c.getColumnIndex("LNAME"));
            spinnerList.add((c.getString(c.getColumnIndex("FNAME"))+" "+c.getString(c.getColumnIndex("LNAME"))));
            employee.position=c.getString(c.getColumnIndex("POSITION"));
            employee.report=c.getInt(c.getColumnIndex("REPORT"));
            employee.birthdate=c.getString(c.getColumnIndex("BIRTHDATE"));
            employee.salary=c.getDouble(c.getColumnIndex("SALARY"));
            Employees.add(employee);
        }
        Log.i("Employees:", "complete entrees"); //updates info log (Logcat)
        Log.i("Employee Example:","id: "+employee.id+" fname: "+employee.fname+" lname: "+employee.lname); //updates info log (Logcat) to check employee is functioning
        if (employee.fname!=null) {
            Spinner spinner = (Spinner) findViewById(R.id.EmployeeSpinner);
            Spinner spinner2 = (Spinner) findViewById(R.id.employeeSpinner);

            Log.i("Spinners:", "spinners set");
            // Application of the Array to the Spinner
            ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, spinnerList);
            spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); // The drop down view
            spinner.setAdapter(spinnerArrayAdapter);
            Log.i("Spinners:", "first spinner set succeeded");
            spinner2.setAdapter(spinnerArrayAdapter);
            Log.i("Spinners:", "second spinner set succeeded");
        }
    }

    Vector<Double> Offense_Vector = new Vector<Double>(9);

    public void GetOffense(View v){
        Spinner spinner3 = (Spinner) findViewById(R.id.employeeSpinner2);
        TextView offenseList = findViewById(R.id.offense_list);
        String employee = (String) spinner3.getSelectedItem();
        String employee_id = doIDQuery(employee);
        String offenses = "";
        Cursor c = myDB.doQuery("SELECT * FROM EMPLOYEES WHERE ID="+employee_id);
        while (c.moveToNext()){
            offenses=offenses+c.getString(c.getColumnIndex("OFFENSES"));
        }
        if (offenses.equals("")){
            offenseList.setText("No offenses");
        }
        else{
            String[] offenseArray = offenses.split(",");
            offenses="";
            int k;
            for (int i=0; i<offenseArray.length; i=i+2){ //note it is incrementing at 2 instead of one to avoid doing mod checks every loop
                k=i+1;
                offenses=offenses+offenseArray[i]+": "+offensecorr(offenseArray[k])+"\n";
            }
            offenseList.setText(offenses);
        }
    }

    public String offensecorr(String offense_num){
        if (offense_num.equals("0")){
            return("late");
        }
        else if (offense_num.equals("1")){
            return("absenteeism");
        }
        else if (offense_num.equals("2")){
            return("improper dress code");
        }
        else if (offense_num.equals("3")){
            return("theft");
        }
        else if (offense_num.equals("4")){
            return("harassment");
        }
        else if (offense_num.equals("5")){
            return("insubordination");
        }
        else if (offense_num.equals("6")){
            return("intimidation");
        }
        else if (offense_num.equals("7")){
            return("anauthorised substance use");
        }
        else{
            return("poor performance");
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void courseRecommend(View v){
        Offense_Vector.setSize(9);
        for (int i=0; i<9; i++) {
            Offense_Vector.set(i, 0.0); //initial vector of 0s
        }
        Spinner spinner3 = (Spinner) findViewById(R.id.employeeSpinner2);
        String employee = (String) spinner3.getSelectedItem();
        String employee_id = doIDQuery(employee);
        Cursor c = myDB.doQuery("SELECT * FROM EMPLOYEES WHERE ID="+employee_id);
        String offenses="";
        if (c.moveToNext()){
            offenses=offenses+c.getString(c.getColumnIndex("OFFENSES"));
        }
        if (!offenses.equals("")){
            String[] offenseArray = offenses.split(",");
            int k;
            int offense;
            Double temp;
            for (int i=0; i<offenseArray.length; i=i+2){ //remember it must not include dates therefore use +2 to skip them
                k=i+1;
                offense=Integer.parseInt(offenseArray[k]);
                temp = Offense_Vector.get(offense); //current number of those offenses
                Offense_Vector.set(offense, temp+1); //then add 1
            }
        }
        Offenses offense_class = new Offenses();
        offense_class.importData();
        String recommendation = offense_class.courseRecommend(Offense_Vector);
        TextView textView = findViewById(R.id.offense_list);
        textView.setText(recommendation);
    }

    public void clearDB(View v){
        getApplicationContext().deleteDatabase("app.db");
        Employees.clear();
        spinnerList.clear();
        Log.i("DB edit","EMPLOYEES table entries erased");
    }
    Vector<EMPLOYEE> assignedButtons0 = new Vector<EMPLOYEE>();
    Vector<EMPLOYEE> assignedButtons1 = new Vector<EMPLOYEE>();
    Vector<EMPLOYEE> assignedButtons2 = new Vector<EMPLOYEE>();

    public void addEmpSet(View v){
        Log.i("Employee Set","function started");
        EMPLOYEE emp = new EMPLOYEE();
        Log.i("Employee Set","new employee");
        String id = nextId();
        Log.i("Employee Set","nextId successful ("+id+")");
        String fname = "Gandalf";
        String lname = "Gray";
        String position = "Master Wizard";
        int report = -1; //reports to no one
        String birthdate = "1980/05/07"; //CHECK FOR CONVERSION
        Double salary = 2000.00;
        String offenses="2010/05/07,7,2017/07/07,2,2020/05/07,7";
        String[] entry={id,fname,lname,position,Integer.toString(report),birthdate,String.valueOf(salary),offenses};
        Log.i("Employee Set","All well before insert");
        myDB.doUpdate("INSERT INTO EMPLOYEES(ID,FNAME,LNAME,POSITION,REPORT,BIRTHDATE,SALARY,OFFENSES) VALUES(?,?,?,?,?,?,?,?)", entry);
        Log.i("Employee Set","Inserted into db fine");
        emp.id=Integer.parseInt(id);
        emp.fname=fname;
        emp.lname=lname;
        emp.position=position;
        emp.report=report;
        emp.birthdate=birthdate;
        emp.salary=salary;
        Log.i("Employee Set","employee variables set");
        Employees.add(emp);
        Log.i("Employee Set","Employee vector updated");

        emp=new EMPLOYEE();
        id = nextId();
        fname = "Samwise";
        lname = "Gangee";
        position = "Self Proclaimed Chef";
        Log.i("Employee Set","right before report");
        report = Integer.parseInt(doIDQuery("Gandalf Gray")); //reports to Gandalf
        Log.i("Employee Set","report successful");
        birthdate = "2000/06/03"; //CHECK FOR CONVERSION
        salary = 200.00;
        offenses="2015/01/05,0,2015/02/07,0,2020/05/01,2,2020/05/01,0";
        entry[0]=id;
        entry[1]=fname;
        entry[2]=lname;
        entry[3]=position;
        entry[4]=Integer.toString(report);
        entry[5]=birthdate;
        entry[6]=String.valueOf(salary);
        entry[7]=offenses;
        myDB.doUpdate("INSERT INTO EMPLOYEES(ID,FNAME,LNAME,POSITION,REPORT,BIRTHDATE,SALARY,OFFENSES) VALUES(?,?,?,?,?,?,?,?)", entry);
        emp.id=Integer.parseInt(id);
        emp.fname=fname;
        emp.lname=lname;
        emp.position=position;
        emp.report=report;
        emp.birthdate=birthdate;
        emp.salary=salary;
        Employees.add(emp);

        emp=new EMPLOYEE();
        id = nextId();
        fname = "Sporeo";
        lname = "Funguy";
        position = "Mushroom Picker";
        report = Integer.parseInt(doIDQuery("Samwise Gangee")); //reports to no one
        birthdate = "1800/01/02"; //CHECK FOR CONVERSION
        salary = 0.02;
        entry[0]=id;
        entry[1]=fname;
        entry[2]=lname;
        entry[3]=position;
        entry[4]=Integer.toString(report);
        entry[5]=birthdate;
        entry[6]=String.valueOf(salary);
        entry[7]="";
        myDB.doUpdate("INSERT INTO EMPLOYEES(ID,FNAME,LNAME,POSITION,REPORT,BIRTHDATE,SALARY,OFFENSES) VALUES(?,?,?,?,?,?,?,?)", entry);
        emp.id=Integer.parseInt(id);
        emp.fname=fname;
        emp.lname=lname;
        emp.position=position;
        emp.report=report;
        emp.birthdate=birthdate;
        emp.salary=salary;
        Employees.add(emp);

        emp=new EMPLOYEE();
        id = nextId();
        fname = "Berrio";
        lname = "Funguy";
        position = "Berry Picker";
        report = Integer.parseInt(doIDQuery("Samwise Gangee")); //reports to no one
        birthdate = "1800/01/01"; //CHECK FOR CONVERSION
        salary = 0.01;
        entry[0]=id;
        entry[1]=fname;
        entry[2]=lname;
        entry[3]=position;
        entry[4]=Integer.toString(report);
        entry[5]=birthdate;
        entry[6]=String.valueOf(salary);
        myDB.doUpdate("INSERT INTO EMPLOYEES(ID,FNAME,LNAME,POSITION,REPORT,BIRTHDATE,SALARY,OFFENSES) VALUES(?,?,?,?,?,?,?,?)", entry);
        emp.id=Integer.parseInt(id);
        emp.fname=fname;
        emp.lname=lname;
        emp.position=position;
        emp.report=report;
        emp.birthdate=birthdate;
        emp.salary=salary;
        Employees.add(emp);

        emp=new EMPLOYEE();
        id = nextId();
        fname = "Frodo";
        lname = "Baggins";
        position = "Tiny Hero";
        report = Integer.parseInt(doIDQuery("Gandalf Gray")); //reports to no one
        birthdate = "2000/03/06"; //CHECK FOR CONVERSION
        salary = 250.00;
        entry[0]=id;
        entry[1]=fname;
        entry[2]=lname;
        entry[3]=position;
        entry[4]=Integer.toString(report);
        entry[5]=birthdate;
        entry[6]=String.valueOf(salary);
        entry[7]="2014/07/03,8,2014/08/02,1,2021/01/02,8";
        myDB.doUpdate("INSERT INTO EMPLOYEES(ID,FNAME,LNAME,POSITION,REPORT,BIRTHDATE,SALARY,OFFENSES) VALUES(?,?,?,?,?,?,?,?)", entry);
        emp.id=Integer.parseInt(id);
        emp.fname=fname;
        emp.lname=lname;
        emp.position=position;
        emp.report=report;
        emp.birthdate=birthdate;
        emp.salary=salary;
        Employees.add(emp);

        emp=new EMPLOYEE();
        id = nextId();
        fname = "Golum";
        lname = "CrawlsALot";
        position = "Advice Giver";
        report = Integer.parseInt(doIDQuery("Frodo Baggins")); //reports to no one
        birthdate = "1900/01/05"; //CHECK FOR CONVERSION
        salary = 0.05;
        entry[0]=id;
        entry[1]=fname;
        entry[2]=lname;
        entry[3]=position;
        entry[4]=Integer.toString(report);
        entry[5]=birthdate;
        entry[6]=String.valueOf(salary);
        entry[7]="2000/01/02,4,2005/02/01,5,2007/02/04,3,2014/05/01,4,2020/11/05,4";
        myDB.doUpdate("INSERT INTO EMPLOYEES(ID,FNAME,LNAME,POSITION,REPORT,BIRTHDATE,SALARY,OFFENSES) VALUES(?,?,?,?,?,?,?,?)", entry);
        emp.id=Integer.parseInt(id);
        emp.fname=fname;
        emp.lname=lname;
        emp.position=position;
        emp.report=report;
        emp.birthdate=birthdate;
        emp.salary=salary;
        Employees.add(emp);
    }

    public void clearButtons(View v){
        TextView emp_info = findViewById(R.id.employee_info);
        emp_info.setText("");

        Button button0 = findViewById(R.id.button0);
        Button button01 = (Button)findViewById(R.id.button01);
        Button button02 = findViewById(R.id.button02);

        Button button1 = findViewById(R.id.button1);
        Button button11 = findViewById(R.id.button11);
        Button button12 = findViewById(R.id.button12);

        Button button2 = findViewById(R.id.button2);
        Button button21 = findViewById(R.id.button21);
        Button button22 = findViewById(R.id.button22);

        button0.setText("");
        button0.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button0.setVisibility(View.INVISIBLE);
        button0.setClickable(false);
        button01.setText("");
        button01.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button01.setVisibility(View.INVISIBLE);
        button01.setClickable(false);
        button02.setText("");
        button02.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button02.setVisibility(View.INVISIBLE);
        button02.setClickable(false);

        button1.setText("");
        button1.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button1.setVisibility(View.INVISIBLE);
        button1.setClickable(false);
        button11.setText("");
        button11.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button11.setVisibility(View.INVISIBLE);
        button11.setClickable(false);
        button12.setText("");
        button12.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button12.setVisibility(View.INVISIBLE);
        button12.setClickable(false);

        button2.setText("");
        button2.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button2.setVisibility(View.INVISIBLE);
        button2.setClickable(false);
        button21.setText("");
        button21.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button21.setVisibility(View.INVISIBLE);
        button21.setClickable(false);
        button22.setText("");
        button22.setBackgroundColor(Color.parseColor("#9E9D9D"));
        button22.setVisibility(View.INVISIBLE);
        button22.setClickable(false);
    }
    Vector<EMPLOYEE> Sort(String according_to, Vector<EMPLOYEE> sortee){ //simply using bubble sort. Complexity is not too important since it's at most 5 employees
        int n = sortee.size();
        Vector<Double> comparitor = new Vector<Double>();
        String[] temp0=new String[3];
        Double[] temp1=new Double[3];
        if (according_to.equals("Birth Date") || according_to.equals("Age")){
            for (int i=0; i<n; i++){
                temp0=sortee.get(i).birthdate.split("/");
                for (int k=0; k<3; k++) {
                    temp1[k]=Double.valueOf(temp0[k]);
                }
                comparitor.add((temp1[0]*365.25)+(temp1[1]*29.53059)+(temp1[2]*1)); //getting years, months, days into total days alive
            }
        }
        else if(according_to.equals("Salary")){
            for (int i=0; i<n; i++){
                comparitor.add(sortee.get(i).salary);
            }
        }
        else{
            return sortee;
        }
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (comparitor.get(j) > comparitor.get(j + 1)) {
                    // swap values[j+1] and values[j]
                    EMPLOYEE tempE = sortee.get(j);
                    Double tempD = comparitor.get(j);
                    sortee.set(j, sortee.get(j + 1));
                    comparitor.set(j, comparitor.get(j + 1));
                    sortee.set(j + 1, tempE);
                    comparitor.set(j + 1, tempD);
                }
            }
        }
        return sortee;
    }

    public void setFirstRow(View v){
        clearButtons(v);
        Spinner sortAccord = findViewById(R.id.filterSpinner);
        String according= (String) sortAccord.getSelectedItem();
        Employees=Sort(according,Employees);
        Vector<Button> buttonList=new Vector<Button>();
        Button button0 = findViewById(R.id.button0);
        Button button01 = findViewById(R.id.button01);
        Button button02 = findViewById(R.id.button02);
        buttonList.add(button0);
        buttonList.add(button01);
        buttonList.add(button02);
        int k=0;
        for (int i=0; i<Employees.size(); i++){
            if (Employees.get(i).report==-1){
                String fullname = Employees.get(i).fname+" "+Employees.get(i).lname;
                buttonList.get(k).setText(fullname);
                buttonList.get(k).setVisibility(View.VISIBLE);
                buttonList.get(k).setClickable(true);
                assignedButtons0.add(Employees.get(i));
                k++;
                if (k==3){
                    break;
                }
            }
        }
    }

    Button parent;
    int parent_index=-1;
    public void setSecondRow0(View v){
        Log.i("SetRow","setSecondRow0(View v) called");
        parent = findViewById(R.id.button0);
        parent_index=0;
        setSecondRow(v);
    }
    public void setSecondRow1(View v){
        Log.i("SetRow","setSecondRow1(View v) called");
        parent = findViewById(R.id.button01);
        parent_index=1;
        setSecondRow(v);
    }
    public void setSecondRow2(View v){
        Log.i("SetRow","setSecondRow2(View v) called");
        parent = findViewById(R.id.button02);
        parent_index=2;
        setSecondRow(v);
    }
    public void setSecondRow(View v){
        Log.i("SetRow","setSecondRow(View v) has begun");
        setFirstRow(v);
        Log.i("SetRow","all previous set to gray");
        Vector<Button> buttonList=new Vector<Button>();
        Button button1 = findViewById(R.id.button1);
        Button button11 = findViewById(R.id.button11);
        Button button12 = findViewById(R.id.button12);
        buttonList.add(button1);
        buttonList.add(button11);
        buttonList.add(button12);
        Log.i("SetRow","buttonList set up");
        parent.setBackgroundColor(Color.parseColor("#8170b5"));
        Log.i("SetRow","color should have changed");
        TextView emp_info = findViewById(R.id.employee_info);
        EMPLOYEE reportingEmp = assignedButtons0.get(parent_index);
        String information="Employee id: "+reportingEmp.id+"\n"+
                "Full Name: "+reportingEmp.fname+" "+reportingEmp.lname+"\n"+
                "Job Description: "+reportingEmp.position+"\n"+
                "Reports To: N/A, No Manager"+"\n"+
                "Birthdate: "+reportingEmp.birthdate+"\n"+
                "Salary in Rands p.a.: "+reportingEmp.salary;
        emp_info.setText(information);
        Log.i("SetRow", "All information handles for selected Row0 employee");

        int k=0;
        for (int i=0; i<Employees.size(); i++){
            if (Employees.get(i).report==reportingEmp.id){
                Log.i("SetRow", "Found someone who reports to "+reportingEmp.fname);
                String fullname = Employees.get(i).fname+" "+Employees.get(i).lname;
                buttonList.get(k).setText(fullname);
                buttonList.get(k).setVisibility(View.VISIBLE);
                buttonList.get(k).setClickable(true);
                assignedButtons1.add(Employees.get(i));
                k++;
                if (k==3){
                    break;
                }
            }
        }
    }

    Button parent2;
    int parent_index2;
    public void setThirdRow0(View v){
        Log.i("SetRow","setThirdRow0(View v)");
        parent2 = findViewById(R.id.button1);
        parent_index2=0;
        setThirdRow(v);
    }
    public void setThirdRow1(View v){
        parent2 = findViewById(R.id.button11);
        parent_index2=1;
        setThirdRow(v);
    }
    public void setThirdRow2(View v){
        parent2 = findViewById(R.id.button12);
        parent_index2=2;
        setThirdRow(v);
    }
    public void setThirdRow(View v){
        setSecondRow(v);

        Vector<Button> buttonList=new Vector<Button>();
        Button button2 = findViewById(R.id.button2);
        Button button21 = findViewById(R.id.button21);
        Button button22 = findViewById(R.id.button22);
        buttonList.add(button2);
        buttonList.add(button21);
        buttonList.add(button22);

        parent2.setBackgroundColor(Color.parseColor("#8170b5"));
        parent.setBackgroundColor(Color.parseColor("#CBC3E3"));
        TextView emp_info = findViewById(R.id.employee_info);
        EMPLOYEE reportingEmp = assignedButtons1.get(parent_index2);
        String information="Employee id: "+reportingEmp.id+"\n"+
                "Full Name: "+reportingEmp.fname+" "+reportingEmp.lname+"\n"+
                "Job Description: "+reportingEmp.position+"\n"+
                "Reports To: "+assignedButtons0.get(parent_index).fname+" "+assignedButtons0.get(parent_index).lname+"\n"+
                "Birthdate: "+reportingEmp.birthdate+"\n"+
                "Salary in Rands p.a.: "+reportingEmp.salary;
        emp_info.setText(information);

        int k=0;
        for (int i=0; i<Employees.size(); i++){
            if (Employees.get(i).report==reportingEmp.id){
                String fullname = Employees.get(i).fname+" "+Employees.get(i).lname;
                buttonList.get(k).setText(fullname);
                buttonList.get(k).setVisibility(View.VISIBLE);
                buttonList.get(k).setClickable(true);
                assignedButtons2.add(Employees.get(i));
                k++;
                if (k==3){
                    break;
                }
            }
        }
    }

    Button me;
    int me_index;
    public void selectThirdRow0(View v) {
        me = findViewById(R.id.button2);
        me_index = 0;
        selectThirdRow(v);
    }
    public void selectThirdRow1(View v) {
        me = findViewById(R.id.button21);
        me_index = 1;
        selectThirdRow(v);
    }
    public void selectThirdRow2(View v) {
        me = findViewById(R.id.button22);
        me_index = 2;
        selectThirdRow(v);
    }

    public void selectThirdRow(View v){
        setThirdRow(v);

        Vector<Button> buttonList=new Vector<Button>();
        Button button2 = findViewById(R.id.button2);
        Button button21 = findViewById(R.id.button21);
        Button button22 = findViewById(R.id.button22);
        buttonList.add(button2);
        buttonList.add(button21);
        buttonList.add(button22);

        buttonList.get(me_index).setBackgroundColor(Color.parseColor("#8170b5"));
        parent2.setBackgroundColor(Color.parseColor("#CBC3E3"));
        TextView emp_info = findViewById(R.id.employee_info);
        EMPLOYEE reportingEmp = assignedButtons2.get(me_index);
        String information="Employee id: "+reportingEmp.id+"\n"+
                "Full Name: "+reportingEmp.fname+" "+reportingEmp.lname+"\n"+
                "Job Description: "+reportingEmp.position+"\n"+
                "Reports To: "+assignedButtons1.get(parent_index2).fname+" "+assignedButtons1.get(parent_index2).lname+"\n"+
                "Birthdate: "+reportingEmp.birthdate+"\n"+
                "Salary in Rands p.a.: "+reportingEmp.salary;
        emp_info.setText(information);
    }

    public void updateDB(View v){
        EditText FNAME = (EditText) v.findViewById(R.id.editTextTextPersonName);
        EditText LNAME = (EditText) v.findViewById(R.id.editTextTextPersonName2);
        EditText POSITION = (EditText)v.findViewById(R.id.editTextTextPersonName3);
        Spinner reportSpinner = (Spinner)v.findViewById(R.id.employeeSpinner);
        String report_query = reportSpinner.getSelectedItem().toString();
        EditText BIRTHDATE = (EditText)v.findViewById(R.id.editTextDate);
        EditText SALARY = (EditText)v.findViewById(R.id.editTextNumberDecimal);

        String id = nextId();
        String fname = FNAME.getText().toString();
        String lname = LNAME.getText().toString();
        String position = POSITION.getText().toString();
        String report = doIDQuery(report_query); //gets int for db insertion
        String birthdate = BIRTHDATE.getText().toString(); //CHECK FOR CONVERSION
        String salary = SALARY.getText().toString();

        EMPLOYEE emp = new EMPLOYEE();

        String[] entry = new String[8];
        entry[0] = id;
        emp.id = Integer.getInteger(id);
        entry[1] = fname;
        emp.fname = fname;
        entry[2] = lname;
        emp.lname = lname;
        entry[3] = position;
        emp.position = position;
        entry[4] = report;
        emp.report = Integer.getInteger(report);
        entry[5] = birthdate;
        emp.birthdate = birthdate;
        entry[6] = salary;
        emp.salary = Double.valueOf(salary);

        myDB.doUpdate("INSERT INTO EMPLOYEES VALUES(?,?,?,?,?,?,?)", entry);
        Employees.add(emp);
    }



    public String nextId(){
        Cursor c = myDB.doQuery("SELECT MAX(ID) AS OLDMAX FROM EMPLOYEES");
        int id=0;
        String output;
        while (c.moveToNext()){ //should be only one entry
            id=c.getInt(c.getColumnIndex("OLDMAX"))+1;
        }
        output=Integer.toString(id);
        return output;
    }

    public String doIDQuery(String fullname){
        String[] names=fullname.split(" ");
        String fnames="";
        String fnames2="";
        String lname="";
        String lname2="";
        Log.i("IDQuery", "names initialised");
        if (names.length==1){
            fnames=fullname;
            lname="NULL";
            Log.i("IDQuery", "only one name");
        }
        else{
            fnames="";
            fnames2=""; //on the off chance that the person has multiple first names but no surname
            lname2="null"; //for the above case
            for (int i=0; i<names.length; i++){
                if (i==names.length-1) {
                    lname = lname + names[i];
                    fnames2 = fnames2 + names[i];
                    Log.i("IDQuery", "last name assigned");
                }
                else if (i==0) {
                    fnames = fnames + names[i];
                    fnames2 = fnames2 + names[i];
                    Log.i("IDQuery", "first name assigned");
                }
                else {
                    fnames = fnames + " " + names[i];
                    fnames2 = fnames2 + " " + names[i];
                    Log.i("IDQuery", "middle names assigned");
                }
            }
        }
        String[] parameters= {fnames,lname};
        Log.i("IDQuery", "up until query good");
        Log.i("IDQuery","fname: "+parameters[0]+" lname: "+parameters[1]);
        String query = "SELECT ID FROM EMPLOYEES WHERE FNAME='"+parameters[0]+"' AND LNAME='"+parameters[1]+"'";
        Cursor cq=myDB.doQuery(query);
        Log.i("IDQuery", "query seems good");
        Log.i("IDQuery", Integer.toString(cq.getColumnIndex("ID")));
        String output="";
        while (cq.moveToNext()){
            Log.i("IDQuery", "got this far");
            output=output+Integer.toString(cq.getInt(0));
            Log.i("IDQuery", "ID Obtained");
        }
        Log.i("IDQuery", "got further");
        if (output.equals("")){
            parameters[0]=fnames2;
            parameters[1]=lname2;
            Cursor c2=myDB.doQuery("SELECT ID FROM EMPLOYEES WHERE FNAME=? AND LNAME=?", parameters);
            while (c2.moveToNext()) {
                output = output + Integer.toString(c2.getInt(c2.getColumnIndex("ID")));
            }
        }
        Log.i("IDQuery", "ID is "+output);
        return output;
    }

}