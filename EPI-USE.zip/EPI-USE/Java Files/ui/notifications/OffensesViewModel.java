package com.example.scpoc.ui.notifications;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class OffensesViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public OffensesViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("Offenses");
    }

    public LiveData<String> getText() {
        return mText;
    }
}