package com.example.scpoc.ui.notifications;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.scpoc.R;
import com.example.scpoc.databinding.FragmentOffensesBinding;

public class OffensesFragment extends Fragment {

    private OffensesViewModel offensesViewModel;
    private FragmentOffensesBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        offensesViewModel =
                new ViewModelProvider(this).get(OffensesViewModel.class);

        binding = FragmentOffensesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textOffenses;
        offensesViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;


    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}